//
//  AppNetRequest.swift
//  Templates
//
//  Created by SanW on 2023/6/8.
//  Copyright © 2023 SanW. All rights reserved.
//

import UIKit

class AppNetRequest: NSObject {}
