//
//  AppMainViewModel.swift
//  Templates
//
//  Created by SanW on 2023/5/26.
//  Copyright © 2023 SanW. All rights reserved.
//

import UIKit

class AppMainViewModel: NSObject {}
