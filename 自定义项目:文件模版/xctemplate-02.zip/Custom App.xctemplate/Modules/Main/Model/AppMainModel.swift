//
//  AppMainModel.swift
//  Templates
//
//  Created by SanW on 2023/5/24.
//  Copyright © 2023 SanW. All rights reserved.
//

import UIKit

class AppMainModel: NSObject {

}
